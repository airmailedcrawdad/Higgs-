This is a public disclosure bundle authored by Joseph Deloza, titled:
"Probabilistic Origin Formalism (POF): Collapse-Based Reinterpretation of the CMB and Gravitational Constant"

Contents:
- Markdown document of full disclosure
- MANIFEST file listing document versions
- Generated PDF (if available)
- SHA256 integrity hashes

Date: 2025-09-01 21:51:55
Location: Wilmington, Delaware
Status: Public Archive Disclosure
